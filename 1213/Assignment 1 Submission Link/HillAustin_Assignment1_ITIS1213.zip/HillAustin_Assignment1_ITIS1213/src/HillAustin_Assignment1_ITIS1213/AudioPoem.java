/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HillAustin_Assignment1_ITIS1213;

import BookClasses.Sound;
import java.util.Random;

/**
 * This class contains methods for mixing up the words in an audio file and
 * creating sound poetry out of them. It contains many stub methods which need
 * to be completed as part of Assignment 1.
 *
 * @author clatulip, (Austin Hill)
 */
public class AudioPoem {

    static final int MAX_NUM_WORDS = 100;
    static private Sound[] myWordArray = new Sound[MAX_NUM_WORDS];

    static private int numWords = 0;

    public AudioPoem(Sound originalSource, int[] spliceArray, int numSplicePoints) {

        // break the sound into sepearate words, copying each into the word array
        for (int i = 0, j = 0; i < numSplicePoints; i = i + 2, j++) {
            myWordArray[j] = new Sound(spliceArray[i + 1] - spliceArray[i]);
            for (int x = spliceArray[i], y = 0; x < spliceArray[i + 1]; x++, y++) {
                myWordArray[j].setSampleValueAt(y, originalSource.getSampleValueAt(x));
            }
            numWords++;
        }

    }

    /**
     * Plays the words, in order with a 200 millisecond pause between each
     * @throws InterruptedException
     */
    public void play() throws InterruptedException {
        // play the words in order
        for (int i = 0; i < numWords; i++) {
            myWordArray[i].blockingPlay();
            Thread.sleep(200);
        }
    }

    /**
     * Plays the words, in order with a parameter-specified pause between each
     * @param pause the number of milliseconds to pause between words
     * @throws InterruptedException
     */
    public void play(int pause) throws InterruptedException {
        //plays the words in order with the pause specified
        for (int i = 0; i < numWords; i++) {
            myWordArray[i].blockingPlay();
            Thread.sleep(pause);
        }
    }
    /**
     * Plays the words, in order with a parameter-specified pause between each and writes the resulting sound out to a file
     * @param pause the number of milliseconds to pause between words
     * @param filename the name of the file to write
     * @param path the path where the file should be written
     * @throws InterruptedException 
     */
    public void play(int pause, String filename, String path) throws InterruptedException {
        int temp = 0; // total number of samples
        double temp2 = ((pause / 1000.0) * 44100); // finds the pause in samples
        
        // get the samples for the words
        for (int i = 0; i < numWords; i++) {
            temp = temp + myWordArray[i].getNumSamples();
        }
        temp = temp + (int)temp2 * numWords;
        Sound s = new Sound(temp); // creates the sound object
        
        int k = 0; // smaple place holder
        int w = 0; // word place hold
        
        // puts the words and pauses in the sound object
        for (int i = 0; i < numWords; i++) {
            for (int j = 0; j < myWordArray[i].getNumSamples(); j++) { //word
         
                s.setSampleValueAt(k, myWordArray[i].getSampleValueAt(j)); 
                k++;
            }
            if (w != numWords) { //pause
                for (int l = 0; l < (int)temp2; l++){
                s.setSampleValueAt(k, 0);
                k++;
                }
            }
            w++;
        }
        s.write(path + filename); // writes the sound object to a file
        s.blockingPlay(); // plays the sound object
        

    }

    /**
     * Plays the words in random order, each word can be played multiple times
     *
     * @param totalWords the total number of words that will be played
     * @param pause the number of milliseconds to pause between words
     * @throws InterruptedException
     */
    public void playRandomOrder(int totalWords, int pause) throws InterruptedException {
        Random r = new Random();
        //plays the words in a random order n times with the pause specified
        // n being the totalWord passed in
        for (int i = 0; i < totalWords; i++) {
            myWordArray[r.nextInt(numWords)].blockingPlay();
            Thread.sleep(pause);
        }
    }
    
    /**
     * Plays the words, in a random order with a parameters-specified totaltWords and pause and writes the resulting sound out to a file
     * @param pause the number of milliseconds to pause between words
     * @param filename the name of the file to write
     * @param path the path where the file should be written
     * @param totalWords the total number of random words
     * @throws InterruptedException 
     */
    public void playRandomOrder(int totalWords, int pause, String filename, String path) throws InterruptedException {
        int temp = 0; // total number of samples
        double temp2 = ((pause / 1000.0) * 44100); // finds the pause in samples
        Random r = new Random(); // creates random object
        int[] hold = new int[totalWords]; // holds the random number
        
        //finds the random word
        for (int i = 0; i < totalWords; i++) {
           hold[i] = r.nextInt(numWords);
        }
        
        // finds the samples of the words
        for (int i = 0; i < totalWords; i++) {
            temp = temp + myWordArray[hold[i]].getNumSamples();
        }
        temp = temp + (int)temp2 * totalWords; // total samples
        Sound s = new Sound(temp); // creates the sound object
        
        int k = 0; // place holder for the samples
        int w = 0; // place holder for the words
        
        //puts the words into the sound object with pauses
        for (int i = 0; i < totalWords; i++) {
            for (int j = 0; j < myWordArray[hold[i]].getNumSamples(); j++) { //words
                s.setSampleValueAt(k, myWordArray[hold[i]].getSampleValueAt(j)); 
                k++;
            }
            if (w != totalWords) { // pauses
                for (int l = 0; l < (int)temp2; l++){
                s.setSampleValueAt(k, 0);
                k++;
                }
            }
            w++;
        }
        s.write(path + filename); // writes sound object to file 
        s.blockingPlay(); // plays sound object
    }
    

    /**
     * Plays the words in random order, playing each word only once
     * @param pause the number of milliseconds to pause between words
     * @throws InterruptedException
     */
    public void playRandomUnique(int pause) throws InterruptedException {
        Random r = new Random(); // random object
        int[] temp = new int[numWords]; // stores the random numbers
        boolean b = false; // verify the random number is unique
        
        //plays the words in a random unique order 
        for (int i = 0; i < numWords; i++) {
            temp[i] = r.nextInt(numWords);
            
            for (int k = 0; k < i; k++) { // verifies the unique word
                if (temp[i] == temp[k]) {
                    i--;
                    b = true;
                    break;
                }
            }
            if (b == false){ // if unique plays the word
            myWordArray[temp[i]].blockingPlay();
            Thread.sleep(pause);
            }
            else{
                b = false; 
            }
        }

    }
    
    /**
     * Plays the words, in a random unique order with parameters pause and writes the resulting sound out to a file
     * @param pause the number of milliseconds to pause between words
     * @param filename the name of the file to write
     * @param path the path where the file should be written
     * @throws InterruptedException 
     */
    public void playRandomUnique(int pause, String filename, String path) throws InterruptedException {
        int temp = 0; // total for samples 
        double temp2 = ((pause / 1000.0) * 44100); // finds the pause in samples
        Random r = new Random(); // creates the random object
        int[] hold = new int[numWords]; // hold the random words
        //plays the words in a random order with the pause specified and checks for unique
        for (int i = 0; i < numWords; i++) { //random number
           hold[i] = r.nextInt(numWords);
           for (int k = 0; k < i; k++) { // check unique
                if (hold[i] == hold[k]) {
                    i--;
                    break;
                }
            }
        }
        
        for (int i = 0; i < numWords; i++) { // finds the samples needed
            temp = temp + myWordArray[hold[i]].getNumSamples();
        }
        temp = temp + (int)temp2 * numWords; // total samples
        Sound s = new Sound(temp); // creates the sound object
        
        int k = 0; // samples place holder
        int w = 0; // words place holder
        
        // puts the words and pauses in the sound object
        for (int i = 0; i < numWords; i++) {
            for (int j = 0; j < myWordArray[hold[i]].getNumSamples(); j++) { // words
         
                s.setSampleValueAt(k, myWordArray[hold[i]].getSampleValueAt(j)); 
                k++;
            }
            if (w != numWords) { //sound
                for (int l = 0; l < (int)temp2; l++){
                s.setSampleValueAt(k, 0);
                k++;
                }
            }
            w++;
        }
        s.write(path + filename); // writes the sound object to a file
        s.blockingPlay(); // plays the sound object
        

    }
    

    /**
     * Plays the sound words in reverse order (e.g. 'this is a test' will be
     * played 'test a is this')
     * @param pause the number of milliseconds to pause between words
     * @throws InterruptedException
     */
    public void playReverseOrder(int pause) throws InterruptedException {
        //plays the words in reverse order with the pause specified
        for (int i = (numWords - 1); i >= 0 ; i--) {
            myWordArray[i].blockingPlay();
            Thread.sleep(pause);
        }
    }
    
    
     /**
     * Plays the words, in reverse order with a parameter-specified pause between each and writes the resulting sound out to a file
     * @param pause the number of milliseconds to pause between words
     * @param filename the name of the file to write
     * @param path the path where the file should be written
     * @throws InterruptedException 
     */
    public void playReverseOrder(int pause, String filename, String path) throws InterruptedException {
        int temp = 0; //total number of samples
        double temp2 = ((pause / 1000.0) * 44100); // finds the pause that the user wants
        for (int i = 0; i < numWords; i++) { // finds the samples needed for the word
            temp = temp + myWordArray[i].getNumSamples();
        }
        temp = temp + (int)temp2 * numWords; // total samples
        Sound s = new Sound(temp); // creates the sound object
        
        int k = 0; // samples place holder
        int w = 0; // words place holder
        
        // puts the words and pauses in the sound object
        for (int i = (numWords - 1); i >= 0; i--) {
            for (int j = 0; j < myWordArray[i].getNumSamples(); j++) { //words
         
                s.setSampleValueAt(k, myWordArray[i].getSampleValueAt(j)); 
                k++;
            }
            if (w != numWords) { //puts the pause between each word in
                for (int l = 0; l < (int)temp2; l++){
                s.setSampleValueAt(k, 0);
                k++;
                }
            }
            w++;
        }
        s.write(path + filename); // writes the sound oject to a file
        s.blockingPlay(); // plays the sound object
        

    }
    

    /**
     * Plays random pairs of consecutive words with only a 100 millisecond pause
     * between them, with a four hundred millisecond pause between pairs Ex: for
     * 'this is a test' a pair would only be 'this is' or 'is a' or 'a test'
     * @param numDoublets the number of doublets to play
     * @throws InterruptedException
     */
    public void playDoublets(int numDoublets) throws InterruptedException {
        Random r = new Random(); // random object
        int temp; // place holder for the random number
        
        // get the random number then sets it to play with a 100 millisecond pause
        //in between and 400 after
        for (int i = 0; i < numDoublets ; i++) {
            temp = r.nextInt(numWords);
            if (temp == (numWords - 1)){ //check to make sure it is not the last word
                i--;
            }
            else { // play the random doublet
                myWordArray[temp].blockingPlay();
                Thread.sleep(100);
                myWordArray[temp + 1].blockingPlay();
                Thread.sleep(400);
            }
        }
    }
    
    /**
     * Plays random pairs of consecutive words with only a 100 millisecond pause
     * between them, with a four hundred millisecond pause between pairs Ex: for
     * 'this is a test' a pair would only be 'this is' or 'is a' or 'a test'
     * will then write the sound object to a file that was passed in
     * @param numDoublets the number of doublets to play
     * @param filename the name the s object will take when written too
     * @param path the path for the folder the file will be put in
     * @throws InterruptedException 
     */
    public void playDoublets(int numDoublets, String filename, String path) throws InterruptedException {
        int temp = 0; //the total for the number of samples that is going to be needed
        double temp2 = ((100 / 1000.0) * 44100); // 100 millisecond pause
        double temp3 = ((400 / 1000.0) * 44100); // 400 millisecond pause
        Random r = new Random(); // creates a random boject
        int[] hold = new int[numDoublets]; // holds the random numbers chossen for the doublets
        //find the random numbers and checks to see if it is the last number 
        // if it is i-- to get a new number
        for (int i = 0; i < numDoublets; i++) {
           hold[i] = r.nextInt(numWords);
           if (hold[i] == (numWords - 1)){
                i--;
            }
        }
        
        //get the samples need for the word 
        for (int i = 0; i < numDoublets; i++) {
            temp = temp + myWordArray[hold[i]].getNumSamples();
            temp = temp + myWordArray[hold[i]+1].getNumSamples();
        }
        temp = temp + (int)temp2 * (numDoublets) + (int)temp3 * numDoublets;
        Sound s = new Sound(temp); //creates the sound object with the samples needed
        
        int k = 0; // sample place holder
        int w = 0; // place hold for how many doublets the program has went through, used for verifcation
        
        // puts the words in at the right sample values with k being the place holder as well
        // as putting the pause in
        for (int i = 0; i < numDoublets; i++) {
            //first word added
            for (int j = 0; j < myWordArray[hold[i]].getNumSamples(); j++) {
         
                s.setSampleValueAt(k, myWordArray[hold[i]].getSampleValueAt(j)); 
                k++;
            }
            if (w != (numDoublets)) { // puts in the 100 millisecond pause
                for (int l = 0; l < (int)temp2; l++){
                s.setSampleValueAt(k, 0);
                k++;
                }
            }
            
            //puts the next word in the sound object
            for (int j = 0; j < myWordArray[hold[i]+1].getNumSamples(); j++) {
         
                s.setSampleValueAt(k, myWordArray[hold[i]+1].getSampleValueAt(j)); 
                k++;
            }
            if (w != numDoublets) { //puts the 400 millisecond pause in 
                for (int l = 0; l < (int)temp3; l++){
                s.setSampleValueAt(k, 0);
                k++;
                }
            }
            w++;
        }
        s.write(path + filename); // writes the sound object to a file
        s.blockingPlay(); // plays the sound object
        

    }
    
    /**
     * Plays random pairs of consecutive words with only a 100 millisecond pause
     * between them, with a four hundred millisecond pause between pairs Ex: for
     * 'this is a test' a pair could be 'test test', 'this is', 'this a'
     * will then write the sound object to a file that was passed in
     * @param numDoublets the number of doublets to play
     * @param filename the name the s object will take when written too
     * @param path the path for the folder the file will be put in
     * @throws InterruptedException 
     */
    public void playRandomDoublets(int numDoublets, String filename, String path) throws InterruptedException {
        int temp = 0; //the total for the number of samples that is going to be needed
        double temp2 = ((100 / 1000.0) * 44100); // 100 millisecond pause
        double temp3 = ((400 / 1000.0) * 44100); // 400 millisecond pause
        Random r = new Random(); // creates a random boject
        int[] hold = new int[(numDoublets * 2)]; // holds the random numbers chossen for the doublets
        //find the random numbers and checks to see if it is the last number 
        // if it is i-- to get a new number
        for (int i = 0; i < (numDoublets * 2); i++) {
           hold[i] = r.nextInt(numWords);
        }
        
        //get the samples need for the word 
        for (int i = 0; i < (numDoublets * 2); i++) {
            temp = temp + myWordArray[hold[i]].getNumSamples();
        }
        temp = temp + (int)temp2 * numDoublets + (int)temp3 * numDoublets;
        Sound s = new Sound(temp); //creates the sound object with the samples needed
        
        int k = 0; // sample place holder
        int w = 0; // place hold for how many doublets the program has went through, used for verifcation
        
        // puts the words in at the right sample values with k being the place holder as well
        // as putting the pause in
        for (int i = 0; i < numDoublets; i++) {
            //first word added
            for (int j = 0; j < myWordArray[hold[w]].getNumSamples(); j++) {
                s.setSampleValueAt(k, myWordArray[hold[w]].getSampleValueAt(j)); 
                k++;
            }
            for (int l = 0; l < (int)temp2; l++){ //pause
            s.setSampleValueAt(k, 0);
            k++;
            }
            w++;
            
            //puts the next word in the sound object
            for (int j = 0; j < myWordArray[hold[w]].getNumSamples(); j++) {
                s.setSampleValueAt(k, myWordArray[hold[w]].getSampleValueAt(j)); 
                k++;
            }
             
            for (int l = 0; l < (int)temp3; l++){
            s.setSampleValueAt(k, 0);
            k++;
            }
            
            w++;
        }
        s.write(path + filename); // writes the sound object to a file
        s.blockingPlay(); // plays the sound object
        

    }
}
