/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hill_austin_assignment3_bank;

/**
 *
 * @author Austin
 */
public abstract class Account {
    private int accountNum; // accoutnID
    private static int nextAccountNum = 1; // the next account id
    private double amount; 
    private double interestRate;

    /**
     * Constructor 
     * @param amount
     * @param interestRate 
     */
    public Account(double amount, double interestRate) {
        this.accountNum = nextAccountNum; // sets the acountNum to the static variable
        updateNextAccountNum(); // updates the nextAccountnum
        this.amount = amount;
        this.interestRate = interestRate;
    }

    /**
     * Getter for accountNum
     * @return 
     */
    public int getAccountNum() {
        return accountNum;
    }

    /**
     * Setter uses the Static field nextAccountNum
     */
    public void setAccountNum() {
        this.accountNum = nextAccountNum;
        updateNextAccountNum();
    }

    /**
     * Getter for amount
     * @return 
     */
    public double getAmount() {
        return amount;
    }

    /**
     * Setter for amount
     * @param amount 
     */
    public void setAmount(double amount) {
        this.amount = amount;
    }

    /**
     * Getter for interest rate
     * @return interest rate as a double
     */
    public double getInterestRate() {
        return interestRate;
    }

    /**
     * Setter for interest rate
     * @param interestRate 
     */
    public void setInterestRate(double interestRate) {
        this.interestRate = interestRate;
    }
    
    /**
     * method used to update the static variable so it is never the same
     */
    public static void updateNextAccountNum(){
        nextAccountNum++;
    }
    
}
