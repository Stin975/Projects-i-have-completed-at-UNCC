/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hill_austin_assignment3_bank;

/**
 *
 * @author Austin
 */
public abstract class Person {
    private String name; // name for the person
    private String address; // address for the person
    private int ID; // id for the person
    private static int nextID = 1; // set the id for next person
    
    /**
     * Constructor
     * @param name
     * @param address 
     */
    public Person(String name, String address) {
        this.name = name;
        this.address = address;
        this.ID = nextID;
        updateNextID();
    }
    
    /**
     * Getter for name
     * @return String
     */
    public String getName() {
        return name;
    }

    /**
     * Setter for name
     * @param name 
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Getter for address
     * @return String
     */
    public String getAddress() {
        return address;
    }

    /**
     * Setter for address
     * @param address 
     */
    public void setAddress(String address) {
        this.address = address;
    }

    /**
     * Getter for id
     * @return integer
     */
    public int getID() {
        return ID;
    }

    /**
     * Setter for id
     */
    public void setID() {
        this.ID = nextID;
        updateNextID();
    }
    
    /**
     * method for updating the static variable
     */
    public static void updateNextID(){
        nextID++;
    }
}
