/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hill_austin_assignment3_bank;

/**
 *
 * @author hotro
 */
public class Checking extends Account {

    /**
     * Constructor
     * @param amount
     * @param interestRate 
     */
    public Checking(double amount, double interestRate) {
        super(amount, interestRate); // supper class constructor
    }
    
    /**
     * method for calculating the interest every month
     */
    public void calculateInterestMonthly(){
        double tempAmount = this.getAmount();
        double tempInterest = this.getInterestRate();
        
        tempAmount = tempAmount + (tempAmount*tempInterest);
        
        this.setAmount(tempAmount);
    }
}
