/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hill_austin_assignment3_bank;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author Austin
 */
public class Costumer extends Person{
    private ArrayList<Account> accounts = new ArrayList<Account>(); // holds the account the costumer has

    /**
     * Constructor
     * @param name
     * @param address 
     */
    public Costumer(String name, String address) {
        super(name, address);
    }

    /**
     * Main Method for adding the accounts to the costumer from the question asked and 
     * if CD account it will ask for how many years.
     * @param amount
     * @param interestRate
     * @param type 
     */
    public void addAccoutn(double amount, double interestRate, String type){
        
        if(type.contains("Checking")){ //validates the type of account
            accounts.add(new Checking(amount, interestRate));
            System.out.println("Your account number is: " + accounts.get(accounts.size()-1).getAccountNum());
        }else if (type.contains("CD")){ //validates the type of account
            int years = 0;
            Scanner sc = new Scanner(System.in);
            while(years < 1){ // finds the number of years can't be -num, 0, or letter
                try{
                    System.out.println("Enter the years this CD is for: ");
                    years = sc.nextInt();
                }catch(InputMismatchException ime){
                        System.out.println("Exception caught in Costumer method: " + ime);
                        System.out.println("You entered something which is not integer!");
                        sc.nextLine();
                } catch(Exception e){
                        System.out.println("Exception caught in addAccount method: " + e);
                }
            }
            
            accounts.add(new CD(amount, interestRate, years));
            System.out.println("Your account number is: " + accounts.get(accounts.size()-1).getAccountNum());
        } else if (type.contains("Saving")) { //validates the type of account
            accounts.add(new Saving(amount, interestRate));
            System.out.println("Your account number is: " + accounts.get(accounts.size()-1).getAccountNum());
        } else { //Error message
            System.out.println("Error! could not add a Account!");
        }
    }
    
    /**
     * Method for removing the account with the id passed in
     * @param accountID 
     */
    public void removeAccount(int accountID){
        boolean temp = false;
        for(Account a: accounts){
            if(a.getAccountNum() == accountID){ //validates the account id
                accounts.remove(a);
                temp = true;
                break;
            }
        }
        if(temp == false){
            System.out.println("Account was not found!");
        } else{
            temp = false;
        }
    }

    
    /**
     * Method to add money to the account from the id passed in and the amount
     * @param accountID
     * @param amount 
     */
    public void addToAccount(int accountID, double amount){
        boolean temp = false;
        for(Account a: accounts){
            if(a.getAccountNum() == accountID){ //validates the account id
               a.setAmount(amount + a.getAmount());
               temp = true;
               break;
            }
        }
        if(temp == false){
            System.out.println("Account was not found!");
        } else{
            temp = false;
        }
    }

    /**
     * Method used to take the amount from an account from the id and amount being passed in.
     * Also makes sure the account has the amount to be taken from before taking it out.
     * CD account can't be taken from until the current year = the year the CD is for
     * @param accountID
     * @param amount 
     */
    public void takeFromAccount(int accountID, double amount){
        boolean temp = false;
        for(Account a: accounts){
            if(a.getAccountNum() == accountID){ //validates the account id
                temp = true;
                if(!a.getClass().toString().contains("CD")){ //validates the account type
                   if (amount < a.getAmount()){ //validates the amount
                       a.setAmount(a.getAmount() - amount);
                       break;
                   } else { // error message
                       System.out.println("There is not enough in the account to take out!");
                       break;
                   }
                }
                if((a.getClass().toString().contains("CD"))){ //validates the account type
                   if ((amount < a.getAmount()) && ((((CD)a).getCurrentYear()) == ((CD)a).getYears())){ //validates the amount and current years
                       a.setAmount(a.getAmount() - amount);
                       break;
                   } else { // error message
                       System.out.println("There is not enough in the account to take out!");
                       System.out.println("Or the year requirment has not been meet yet so you can't take from the account!");
                       break;
                   }
                } 
                
            }
        }
        if(temp == false){
            System.out.println("Account was not found!");
        } else{
            temp = false;
        }
    }
    
    /**
     * Method for transferring between two accounts takes in two account id, amount and then verifies them before transferring.
     * @param accountID1
     * @param accountID2
     * @param amount 
     */
    public void transferBetweenAccounts(int accountID1, int accountID2, double amount){
        boolean a1 = false;
        boolean a2 = false;
        
        for(Account a: accounts){
            if(a.getAccountNum() == accountID1){ //validates the account id
                if (!a.getClass().toString().contains("CD")){ //validates the account type
                    if (amount < a.getAmount()){ //validates the amount
                        a1 = true;
                    }
                }
            }
            if(a.getAccountNum() == accountID2){ //validates the account id
                if (!a.getClass().toString().contains("CD")){ //validates the account type
                    a2 = true;
                }
            }
        }
        
        if (a1 == true && a2 == true){ // both account have the required validation
            for(Account a: accounts){
            if(a.getAccountNum() == accountID1){ //validates the account id
                a.setAmount((a.getAmount() - amount));
            }
            if(a.getAccountNum() == accountID2){ //validates the account id
                a.setAmount((a.getAmount() + amount));
            }
        }
        } else if (a1 == true && a2 == false){ // error with second account
            System.out.println("The second account is not your account or does not exist!");
        } else if (a1 == false && a2 == true) { // error with first account
            System.out.println("The first account is not your account or does not exist! \n Or does not have the funds to transfer.");
        } else { //error with method
            System.out.println("Error! Both accounts don't exist or are CD acounts!");
        }
        
    }
    
    /**
     * Method for changing the interest rate
     * @param accountID
     * @param interestRate 
     */
    public void changeInterestRate(int accountID, double interestRate){
        for(Account a: accounts){
            if(a.getAccountNum() == accountID){ //validates the account id
                a.setInterestRate(interestRate);
            }
        }
    }
    
    /**
     * Getter for interestRate 
     * @param accountID
     * @return 
     */
    public double getInterestRate(int accountID){
        double tempRate = 0;
        for(Account a: accounts){
            if(a.getAccountNum() == accountID){ //validates the account id
                 tempRate = a.getInterestRate();
            }
        }
         return tempRate;
    }
    
    /**
     * Getter for CD accounts years
     * @param accountID
     * @return 
     */
    public int getYears(int accountID){
        int tempYears = 0;
        for(Account a: accounts){
            if(a.getAccountNum() == accountID){ //validates the account id
                 tempYears = ((CD)a).getYears();
            }
        }
         return tempYears;
    }
    
    /**
     * Getter for current years
     * @param accountID
     * @return 
     */
    public int getCurrentYear(int accountID){
        int tempYears = 0;
        for(Account a: accounts){
            if(a.getAccountNum() == accountID){ //validates the account id
                 tempYears = ((CD)a).getCurrentYear();
            }
        }
         return tempYears;
    }
    
    /**
     *  Method for printing the accounts the costumer has with the amount and id being outputted
     */
    public void printAccounts(){
        int counter = 0;
        System.out.println("Name: " + this.getName()); // prints name
        System.out.println("Saving:"); 
        for(Account a: accounts){ // prints the saving accounts
            if(a.getClass().toString().contains("Saving")){
                System.out.println("Account number: " + a.getAccountNum() + " Amount: " + a.getAmount());
                counter++;
            }
            
        }
        
        if(counter == 0){ 
            System.out.println("No Accounts!");
            counter = 0;
        }
        counter = 0;
        
        System.out.println("Checking:");
        for(Account a: accounts){ // prints checking accounts
            if(a.getClass().toString().contains("Checking")){
                System.out.println("Account number: " + a.getAccountNum() + " Amount: " + a.getAmount());
                counter++;
            }
            
        }
        
        if(counter == 0){
            System.out.println("No Accounts!");
            counter = 0;
        }
        counter = 0;
        
        System.out.println("CD:");
        for(Account a: accounts){ // prints CD accounts
            if(a.getClass().toString().contains("CD")){
                System.out.println("Account number: " + a.getAccountNum() + " Amount: " + a.getAmount());
                counter++;
            }
            
        }
        
        if(counter == 0){
            System.out.println("No Accounts!");
            counter = 0;
        }
        counter = 0;
       
    }
    
    /**
     * Method that calculates the interest Monthly for all account the costumer has
     */
    public void interestMonthly(){
        for (Account a : accounts){ // calculates the interest for both savinand checking accounts
            if(a.getClass().toString().contains("Saving")){
                ((Saving)a).calculateInterestMonthly();
            } else if (a.getClass().toString().contains("Checking")){
                ((Checking)a).calculateInterestMonthly();
            } else{
                
            }
        }
    }
    
    /**
     * Method that calculates the interest yearly for all account the costumer has
     */
    public void interestYearly(){
        for (int i = 0; i <12; i++){ // calls monthly 12 time for there accoutns
            interestMonthly();
        }
        
        for (Account a : accounts){ // CD yearly interest calculated 
            if(a.getClass().toString().contains("CD")){
                ((CD)a).calculateInterestYearly();
            }
        }
    }
    
}
