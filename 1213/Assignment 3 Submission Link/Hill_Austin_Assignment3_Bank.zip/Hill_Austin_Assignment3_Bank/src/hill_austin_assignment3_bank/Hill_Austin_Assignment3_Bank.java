/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hill_austin_assignment3_bank;

/**
 *
 * @author Austin
 */
public class Hill_Austin_Assignment3_Bank {

    /**
     * Main 
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String bankName = "Bank of America";
        String bankAddress = "123 Something St.";
        Bank b = new Bank(bankName, bankAddress);
        b.runningBank(); 
    }
    
}
