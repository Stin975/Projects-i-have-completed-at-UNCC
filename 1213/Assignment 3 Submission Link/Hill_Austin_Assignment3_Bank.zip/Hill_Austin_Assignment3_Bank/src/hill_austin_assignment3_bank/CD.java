/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hill_austin_assignment3_bank;

/**
 *
 * @author hotro
 */
public class CD extends Account{
    private int years; // year the cd is for
    private int currentYear = 0; // the current year the CD is on

    /**
     * Constructor
     * @param amount
     * @param interestRate
     * @param years 
     */
    public CD(double amount, double interestRate, int years) {
        super(amount, interestRate); // super class constructor
        this.years = years;
    }

    /**
     * Getter for years
     * @return 
     */
    public int getYears() {
        return years;
    }

    /**
     * Getter for the current years
     * @return 
     */
    public int getCurrentYear() {
        return currentYear;
    }

    /**
     * Setter for current year
     * @param currentYear 
     */
    public void setCurrentYear(int currentYear) {
        this.currentYear = currentYear;
    }
    
    
    /**
     * method for calculating the interest every year
     */
    public void calculateInterestYearly(){
        double tempAmount = this.getAmount();
        double tempInterest = this.getInterestRate();
        
        if (currentYear < years){
        tempAmount = tempAmount + (tempAmount*tempInterest);
        this.currentYear++;
        }
        
        this.setAmount(tempAmount);
        
    }
}
