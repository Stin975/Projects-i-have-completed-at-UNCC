/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hill_austin_assignment3_bank;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author hotro
 */
public class Bank {

    private String name; // name field
    private String address; // address field
    private ArrayList<Person> persons = new ArrayList<Person>(); // person list

    /**
     * Constructor
     * @param name
     * @param address 
     */
    public Bank(String name, String address) {
        this.name = name;
        this.address = address;
    }

    /**
     * Main Method has the first set of choices Costumer, Employee, Advance months, Advance years, and quit
     * ask the person what they want to do
     */
    public void runningBank() {
        boolean quit = false; // does the person want to quit
        int choice = 0;
        int months = 0;
        int years = 0;
        while (quit == false) {
            Scanner sc = new Scanner(System.in);

            while (choice == 0) {
                try {
                    System.out.println("Choose: ");
                    System.out.println("1. Costumer");
                    System.out.println("2. Employee");
                    System.out.println("3. Advance a number of months.");
                    System.out.println("4. Advance a number of years.");
                    System.out.println("5. Quit");
                    choice = sc.nextInt();
                    if (!(choice == 1 || choice == 2 || choice == 3 || choice == 4 || choice == 5)) { //validates the choice
                        System.out.println("Error! You did not enter one of the choices!");
                    }
                } catch (InputMismatchException ime) {
                    System.out.println("Exception caught in runningBank method: " + ime);
                    System.out.println("You entered something which is not integer!");
                    sc.nextLine();
                } catch (Exception e) {
                    System.out.println("Exception caught in addAccount method: " + e);
                    System.out.println("You did not enter one of the choices");
                    sc.nextLine();
                }
            }

            switch (choice) {
                case 1:
                    costumerChoices(); // another main method
                    choice = 0;
                    break;
                case 2:
                    employeeChoices(); // another main method
                    choice = 0;
                    break;
                case 3:
                    while (months < 1) { // finds the number of months can't be -num, 0, or letter
                        try {
                            System.out.println("Enter the number of months you want to pass: ");
                            months = sc.nextInt();
                        } catch (InputMismatchException ime) {
                            System.out.println("Exception caught in Costumer method: " + ime);
                            System.out.println("You entered something which is not integer!");
                            sc.nextLine();
                        } catch (Exception e) {
                            System.out.println("Exception caught in addAccount method: " + e);
                        }
                    }
                    monthPass(months); // main method
                    months = 0;
                    choice = 0;
                    break;
                case 4:
                    while (years < 1) { // finds the number of years can't be -num, 0, or letter
                        try {
                            System.out.println("Enter the number of years you want to pass: ");
                            years = sc.nextInt();
                        } catch (InputMismatchException ime) {
                            System.out.println("Exception caught in Costumer method: " + ime);
                            System.out.println("You entered something which is not integer!");
                            sc.nextLine();
                        } catch (Exception e) {
                            System.out.println("Exception caught in addAccount method: " + e);
                        }
                    }
                    yearPass(years); // main method
                    years = 0;
                    choice = 0;
                    break;
                case 5:
                    quit = true;
                    choice = 0;
                    break;
                default:
                    quit = false;
                    choice = 0;

            }
        }
    }

    /**
     * Method for adding a new person
     * @param name
     * @param address
     * @param type 
     */
    public void addPerson(String name, String address, char type) {
        double hourlyRate = 0;
        Scanner sc = new Scanner(System.in);

        if (type == 'C') {
            persons.add(new Costumer(name, address));
            System.out.println("Id number is: " + persons.get(persons.size() - 1).getID());
        } else if (type == 'E') {
            while (hourlyRate < 1) { // finds the number of hourlyrate can't be -num, 0, or letter
                try {
                    System.out.println("Enter the your hourly rate: ");
                    hourlyRate = sc.nextDouble();
                } catch (InputMismatchException ime) {
                    System.out.println("Exception caught in Costumer method: " + ime);
                    System.out.println("You entered something which is not number!");
                    sc.nextLine();
                } catch (Exception e) {
                    System.out.println("Exception caught in addPerson method: " + e);
                }
            }

            persons.add(new Employee(name, address, hourlyRate));
            System.out.println("Id number is: " + persons.get(persons.size() - 1).getID());
        } else {
            System.out.println("Error! Should not see this!");
        }
    }

    /**
     * Method for removing a person
     * @param accountId 
     */
    public void removePerson(int accountId) {
        boolean removed = false;
        for (Person p : persons) {
            if (p.getID() == accountId) { //validates the person id
                persons.remove(p);
                removed = true;
                System.out.println("Account removed!");
                break;
            }
        }
        if (removed == false) {
            System.out.println("Account not found or was not removed!");
        }
    }

    /**
     * Main Method for calculating the paychecks and interest for all employees and costumers.
     * uses the number the user inputs to advance that many months
     * @param numOfMonths 
     */
    public void monthPass(int numOfMonths) {
        int year = numOfMonths / 12;
        
        int remainder = numOfMonths % 12;
        Random r = new Random();
        for (Person a : persons) {
            if (a.getClass().toString().contains("Costumer")) {
                for (int i = 0; i < year; i++) {
                    ((Costumer) a).interestYearly();
                }
                if(remainder != 0){
                    for (int i = 0; i < remainder; i++) {
                        ((Costumer) a).interestMonthly();
                    }
                }
            }
            if (a.getClass().toString().contains("Employee")) {
                for (int i = 0; i < 2*numOfMonths; i++) {
                    ((Employee) a).payCheckTwoWeeks(r.nextInt(50), r.nextInt(50));
                }
            }
        }

    }

    /**
     * Main Method for calculating the paychecks and interest for all employees and costumers.
     * uses the number the user inputs to advance that many years
     * @param numOfYears 
     */
    public void yearPass(int numOfYears) {
        Random r = new Random();
        for (Person a : persons) {
            if (a.getClass().toString().contains("Costumer")) {
                for (int i = 0; i < numOfYears; i++) {
                    ((Costumer) a).interestYearly();
                }
            }
            if (a.getClass().toString().contains("Employee")) {
                for (int i = 0; i < 26; i++) {
                    ((Employee) a).payCheckTwoWeeks(r.nextInt(50), r.nextInt(50));
                }
            }
        }
    }

    /**
     * Method use to add money to a costumer account
     * @param personID
     * @param accountID
     * @param amount 
     */
    public void deposit(int personID, int accountID, double amount) {
        for (Person a : persons) {
            if (a.getID() == personID) {
                ((Costumer) a).addToAccount(accountID, amount);
            }
        }
    }

    /**
     * Method used to take money from costumer account
     * @param personID
     * @param accountID
     * @param amount 
     */
    public void withDrawal(int personID, int accountID, double amount) {
        for (Person a : persons) {
            if (a.getID() == personID) {
                ((Costumer) a).takeFromAccount(accountID, amount);
            }
        }
    }

    /**
     * Method used to transfer money between accounts
     * @param personID
     * @param accountID1
     * @param accountID2
     * @param amount 
     */
    public void transferBetweenAccounts(int personID, int accountID1, int accountID2, double amount) {
        for (Person a : persons) {
            if (a.getID() == personID) {
                ((Costumer) a).transferBetweenAccounts(accountID1, accountID2, amount);
            }
        }
    }

    /**
     * Method used to print the employees name and past paychecks
     */
    public void printEmployeesEarnings() {
        for (Person a : persons) {
            if (a.getClass().toString().contains("Employee")) {
                ((Employee) a).printPastPayChecks();
                System.out.println("");
            }
        }
    }

    /**
     * Method use to print costumer accounts
     */
    public void printCostumersAndAccounts() {
        for (Person a : persons) {
            if (a.getClass().toString().contains("Costumer")) {
                ((Costumer) a).printAccounts();
                System.out.println("");
            }
        }
    }

    /**
     * Main method used to to ask for user choice of adding/removing costumer, adding/removing accounts, adding/removing money from accounts
     * transferring from accounts, print the accounts, and back to home
     */
    public void costumerChoices() {
        boolean quit = false;
        int choice = 0;
        int whichAccount = 0;
        double interestRate = 0;
        int personID = 0;
        double amount = 0;
        int accountID = 0;
        int accountID2 =0;
        String type = null;
        String name = null;
        String address = null;
        boolean foundAccount = false;
        
        while (quit == false) {
            Scanner sc = new Scanner(System.in);

            while (choice == 0) {
                try {
                    System.out.println("Choose: ");
                    System.out.println("1. New costumer.");
                    System.out.println("2. Add a account.");
                    System.out.println("3. Deposit");
                    System.out.println("4. Withdrawal");
                    System.out.println("5. Transfer");
                    System.out.println("6. Print costumer accounts");
                    System.out.println("7. Remove Costumer");
                    System.out.println("8. Remove Account");
                    System.out.println("9. Back to home.");
                    choice = sc.nextInt();
                    if (!(choice == 1 || choice == 2 || choice == 3 || choice == 4 || choice == 5 || choice == 6 || choice == 7 || choice == 8 || choice == 9)) {
                        System.out.println("Error! You did not enter one of the choices!");
                    }
                } catch (InputMismatchException ime) {
                    System.out.println("Exception caught in runningBank method: " + ime);
                    System.out.println("You entered something which is not integer!");
                    sc.nextLine();
                } catch (Exception e) {
                    System.out.println("Exception caught in addAccount method: " + e);
                    System.out.println("You did not enter one of the choices");
                    sc.nextLine();
                }
            }

            switch (choice) {
                case 1:
                    System.out.println("Enter your name: ");
                    name = sc.next();
                    System.out.println("Enter your Address: ");
                    address = sc.next();
                    addPerson(name, address, 'C');
                    choice = 0;
                    name = null;
                    address = null;
                    break;
                case 2:
                    while (whichAccount == 0) {
                        try {
                            System.out.println("Choose: ");
                            System.out.println("1. Checking");
                            System.out.println("2. Saving");
                            System.out.println("3. CD");
                            whichAccount = sc.nextInt();
                            if (!(choice == 1 || choice == 2 || choice == 3)) {
                                System.out.println("Error! You did not enter one of the choices!");
                            }
                        } catch (InputMismatchException ime) {
                            System.out.println("Exception caught in runningBank method: " + ime);
                            System.out.println("You entered something which is not integer!");
                            sc.nextLine();
                        } catch (Exception e) {
                            System.out.println("Exception caught in addAccount method: " + e);
                            System.out.println("You did not enter one of the choices");
                            sc.nextLine();
                        }
                    }
                    
                    while (personID <= 0) {
                        try {
                            System.out.println("Enter your personal ID: ");
                            personID = sc.nextInt();
                        } catch (InputMismatchException ime) {
                            System.out.println("Exception caught in runningBank method: " + ime);
                            System.out.println("You entered something which is not integer!");
                            sc.nextLine();
                        } catch (Exception e) {
                            System.out.println("Exception caught in addAccount method: " + e);
                            System.out.println("");
                        }
                    }

                    while (interestRate <= 0) {
                        try {
                            System.out.println("Enter your interest rate as a %: ");
                            System.out.println("Example: '1.25' would be 1.25%");
                            interestRate = sc.nextDouble();
                        } catch (InputMismatchException ime) {
                            System.out.println("Exception caught in runningBank method: " + ime);
                            System.out.println("You entered something which is not integer!");
                            sc.nextLine();
                        } catch (Exception e) {
                            System.out.println("Exception caught in addAccount method: " + e);
                            System.out.println("");
                        }
                    }

                    while (amount <= 0) {
                        try {
                            System.out.println("Enter the amount: ");
                            amount = sc.nextDouble();
                        } catch (InputMismatchException ime) {
                            System.out.println("Exception caught in runningBank method: " + ime);
                            System.out.println("You entered something which is not integer!");
                            sc.nextLine();
                        } catch (Exception e) {
                            System.out.println("Exception caught in addAccount method: " + e);
                        }
                    }

                    if (whichAccount == 1) {
                        type = "Checking";
                    }
                    if (whichAccount == 2) {
                        type = "Saving";
                    }
                    if (whichAccount == 3) {
                        type = "CD";
                    }

                    for (Person a : persons) {
                        if (a.getID() == personID) {
                            ((Costumer) a).addAccoutn(amount, (interestRate / 100), type);
                            foundAccount = true;
                        }
                    }
                    
                    if(foundAccount == false){
                        System.out.println("Error! Did not find a person with this ID!");
                        
                    }
                    foundAccount = false;
                    choice = 0;
                    whichAccount = 0;
                    interestRate = 0;
                    personID = 0;
                    amount = 0;
                    type = null;
                    break;
                case 3:
                    while (personID <= 0) {
                        try {
                            System.out.println("Enter your personal ID: ");
                            personID = sc.nextInt();
                        } catch (InputMismatchException ime) {
                            System.out.println("Exception caught in runningBank method: " + ime);
                            System.out.println("You entered something which is not integer!");
                            sc.nextLine();
                        } catch (Exception e) {
                            System.out.println("Exception caught in addAccount method: " + e);
                            System.out.println("");
                        }
                    }

                    while (accountID <= 0) {
                        try {
                            System.out.println("Enter your account ID: ");
                            accountID = sc.nextInt();
                        } catch (InputMismatchException ime) {
                            System.out.println("Exception caught in runningBank method: " + ime);
                            System.out.println("You entered something which is not integer!");
                            sc.nextLine();
                        } catch (Exception e) {
                            System.out.println("Exception caught in addAccount method: " + e);
                            System.out.println("");
                        }
                    }

                    while (amount <= 0) {
                        try {
                            System.out.println("Enter the amount: ");
                            amount = sc.nextDouble();
                        } catch (InputMismatchException ime) {
                            System.out.println("Exception caught in runningBank method: " + ime);
                            System.out.println("You entered something which is not integer!");
                            sc.nextLine();
                        } catch (Exception e) {
                            System.out.println("Exception caught in addAccount method: " + e);
                        }
                    }

                    for (Person a : persons) {
                        if (a.getID() == personID) {
                            ((Costumer) a).addToAccount(accountID, amount);
                            foundAccount = true;
                        }
                    }
                    if(foundAccount == false){
                        System.out.println("Error! Did not find a person with this ID!");
                        
                    }
                    foundAccount = false;
                    choice = 0;
                    accountID = 0;
                    personID = 0;
                    amount = 0;
                    break;
                case 4:
                    while (personID <= 0) {
                        try {
                            System.out.println("Enter your personal ID: ");
                            personID = sc.nextInt();
                        } catch (InputMismatchException ime) {
                            System.out.println("Exception caught in runningBank method: " + ime);
                            System.out.println("You entered something which is not integer!");
                            sc.nextLine();
                        } catch (Exception e) {
                            System.out.println("Exception caught in addAccount method: " + e);
                            System.out.println("");
                        }
                    }

                    while (accountID <= 0) {
                        try {
                            System.out.println("Enter your account ID: ");
                            accountID = sc.nextInt();
                        } catch (InputMismatchException ime) {
                            System.out.println("Exception caught in runningBank method: " + ime);
                            System.out.println("You entered something which is not integer!");
                            sc.nextLine();
                        } catch (Exception e) {
                            System.out.println("Exception caught in addAccount method: " + e);
                            System.out.println("");
                        }
                    }
                    while (amount <= 0) {
                        try {
                            System.out.println("Enter the amount: ");
                            amount = sc.nextDouble();
                        } catch (InputMismatchException ime) {
                            System.out.println("Exception caught in runningBank method: " + ime);
                            System.out.println("You entered something which is not integer!");
                            sc.nextLine();
                        } catch (Exception e) {
                            System.out.println("Exception caught in addAccount method: " + e);
                        }
                    }

                    for (Person a : persons) {
                        if (a.getID() == personID) {
                            ((Costumer) a).takeFromAccount(accountID, amount);
                            foundAccount=true;
                        }
                    }
                    if(foundAccount == false){
                        System.out.println("Error! Did not find a person with this ID!");
                        
                    }
                    foundAccount = false;
                    accountID = 0;
                    personID = 0;
                    amount = 0;
                    choice = 0;
                    break;
                case 5:
                    while (personID <= 0) {
                        try {
                            System.out.println("Enter your personal ID: ");
                            personID = sc.nextInt();
                        } catch (InputMismatchException ime) {
                            System.out.println("Exception caught in runningBank method: " + ime);
                            System.out.println("You entered something which is not integer!");
                            sc.nextLine();
                        } catch (Exception e) {
                            System.out.println("Exception caught in addAccount method: " + e);
                            System.out.println("");
                        }
                    }

                    while (accountID <= 0) {
                        try {
                            System.out.println("Enter your account ID for the one being taken from: ");
                            accountID = sc.nextInt();
                        } catch (InputMismatchException ime) {
                            System.out.println("Exception caught in runningBank method: " + ime);
                            System.out.println("You entered something which is not integer!");
                            sc.nextLine();
                        } catch (Exception e) {
                            System.out.println("Exception caught in addAccount method: " + e);
                            System.out.println("");
                        }
                    }
                    
                    while (accountID2 <= 0) {
                        try {
                            System.out.println("Enter your account ID for the one receiving the money: ");
                            accountID2 = sc.nextInt();
                        } catch (InputMismatchException ime) {
                            System.out.println("Exception caught in runningBank method: " + ime);
                            System.out.println("You entered something which is not integer!");
                            sc.nextLine();
                        } catch (Exception e) {
                            System.out.println("Exception caught in addAccount method: " + e);
                            System.out.println("");
                        }
                    }
                    
                    while (amount <= 0) {
                        try {
                            System.out.println("Enter the amount: ");
                            amount = sc.nextDouble();
                        } catch (InputMismatchException ime) {
                            System.out.println("Exception caught in runningBank method: " + ime);
                            System.out.println("You entered something which is not integer!");
                            sc.nextLine();
                        } catch (Exception e) {
                            System.out.println("Exception caught in addAccount method: " + e);
                        }
                    }

                    for (Person a : persons) {
                        if (a.getID() == personID) {
                            ((Costumer) a).transferBetweenAccounts(accountID, accountID2, amount);
                            foundAccount=true;
                        }
                    }
                    
                    if(foundAccount == false){
                        System.out.println("Error! Did not find a person with this ID!");
                        
                    }
                    foundAccount = false;
                    accountID = 0;
                    accountID2 =0;
                    personID = 0;
                    amount = 0;
                    
                    choice = 0;
                    break;
                case 6:
                    printCostumersAndAccounts();
                    choice = 0;
                    break;
                case 7:
                    while (personID <= 0) {
                        try {
                            System.out.println("Enter your personal ID: ");
                            personID = sc.nextInt();
                        } catch (InputMismatchException ime) {
                            System.out.println("Exception caught in runningBank method: " + ime);
                            System.out.println("You entered something which is not integer!");
                            sc.nextLine();
                        } catch (Exception e) {
                            System.out.println("Exception caught in addAccount method: " + e);
                            System.out.println("");
                        }
                    }
                    
                    for (Person a : persons) {
                        if (a.getID() == personID) {
                            persons.remove(a);
                            foundAccount=true;
                            choice = 0;
                            System.out.println("Removed!");
                            break;
                        }
                    }
                    
                    if(foundAccount == false){
                        System.out.println("Error! Did not find a person with this ID!");
                        
                    }
                    
                    personID = 0;
                    foundAccount = false;
                    choice = 0;
                    break;
                case 8:
                    personID = 0;
                    foundAccount = false;
                    accountID = 0;
                    while (personID <= 0) {
                        try {
                            System.out.println("Enter your personal ID: ");
                            personID = sc.nextInt();
                        } catch (InputMismatchException ime) {
                            System.out.println("Exception caught in runningBank method: " + ime);
                            System.out.println("You entered something which is not integer!");
                            sc.nextLine();
                        } catch (Exception e) {
                            System.out.println("Exception caught in addAccount method: " + e);
                            sc.nextLine();
                        }
                    }

                    while (accountID <= 0) {
                        try {
                            System.out.println("Enter your account ID for the one being removed: ");
                            accountID = sc.nextInt();
                        } catch (InputMismatchException ime) {
                            System.out.println("Exception caught in runningBank method: " + ime);
                            System.out.println("You entered something which is not integer!");
                            sc.nextLine();
                        } catch (Exception e) {
                            System.out.println("Exception caught in addAccount method: " + e);
                            sc.nextLine();
                        }
                    }
                    
                    for (Person a : persons) {
                        if (a.getID() == personID) {
                            ((Costumer)a).removeAccount(accountID);
                            foundAccount=true;
                            choice = 0;
                            System.out.println("Removed!");
                            break;
                        }
                    }
                    
                    if(foundAccount == false){
                        System.out.println("Error! Did not find a person with this ID!");
                        
                    }
                    personID = 0;
                    foundAccount = false;
                    accountID = 0;
                    choice = 0;
                    break;
                case 9:
                    quit = true;
                    choice = 0;
                    break;
                default:
                    quit = false;

            }
        }
    }

    /**
     * Main method use to create a new employee, change hourly rate, print all employees, and return
     */
    public void employeeChoices() {
        boolean quit = false;
        int choice = 0;
        double hourlyRate = 0;
        int personID = 0;
        boolean foundAccount = false;
        while (quit == false) {
            Scanner sc = new Scanner(System.in);

            while (choice == 0) {
                try {
                    System.out.println("Choose: ");
                    System.out.println("1. New employee");
                    System.out.println("2. Change hourly rate");
                    System.out.println("3. Print employees.");
                    System.out.println("4. Return");
                    choice = sc.nextInt();
                    if (!(choice == 1 || choice == 2 || choice == 3 || choice == 4)) {
                        System.out.println("Error! You did not enter one of the choices!");
                    }
                } catch (InputMismatchException ime) {
                    System.out.println("Exception caught in runningBank method: " + ime);
                    System.out.println("You entered something which is not integer!");
                    sc.nextLine();
                } catch (Exception e) {
                    System.out.println("Exception caught in addAccount method: " + e);
                    System.out.println("You did not enter one of the choices");
                    sc.nextLine();
                }
            }

            switch (choice) {
                case 1:
                    System.out.println("Enter your name: ");
                    name = sc.next();
                    System.out.println("Enter your Address: ");
                    address = sc.next();
                    addPerson(name, address, 'E');
                    choice = 0;
                    name = null;
                    address = null;
                    break;
                case 2:
                    while (personID <= 0) {
                        try {
                            System.out.println("Enter your personal ID: ");
                            personID = sc.nextInt();
                        } catch (InputMismatchException ime) {
                            System.out.println("Exception caught in runningBank method: " + ime);
                            System.out.println("You entered something which is not integer!");
                            sc.nextLine();
                        } catch (Exception e) {
                            System.out.println("Exception caught in addAccount method: " + e);
                            sc.nextLine();
                        }
                    }
                    
                    while (hourlyRate <= 0) {
                        try {
                            System.out.println("Enter yor hourly rate: ");
                            hourlyRate = sc.nextDouble();
                        } catch (InputMismatchException ime) {
                            System.out.println("Exception caught in runningBank method: " + ime);
                            System.out.println("You entered something which is not integer!");
                            sc.nextLine();
                        } catch (Exception e) {
                            System.out.println("Exception caught in addAccount method: " + e);
                        }
                    }
                    
                    for (Person a : persons) {
                        if (a.getID() == personID) {
                            ((Employee)a).setHourlyRate(hourlyRate);
                            foundAccount=true;
                            choice = 0;
                            break;
                        }
                    }
                    
                    if(foundAccount == false){
                        System.out.println("Error! Did not find a person with this ID!");
                        
                    }
                    personID = 0;
                    foundAccount = false;
                    choice = 0;
                    break;
                case 3:
                    printEmployeesEarnings();
                    choice = 0;
                    break;
                case 4:
                    quit = true;
                    choice = 0;
                    break;
                default:
                    quit = false;
            }
        }    
    }
}
