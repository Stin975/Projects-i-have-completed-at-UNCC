/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hill_austin_assignment3_bank;

import java.util.ArrayList;

/**
 *
 * @author hotro
 */
public class Employee extends Person {
    private double hourlyRate; // hourly rate for the employee 
    private int hoursWorked; // hours worked by the employee
    private double earned; // the amount earned
    private ArrayList<Double> pastPayChecks = new ArrayList<Double>(); // holds the past paychecks
    private ArrayList<Integer> pastHours = new ArrayList<Integer>(); // holds the the past hour for the past paychecks

    /**
     * Constructor
     * @param name
     * @param address
     * @param hourlyRate 
     */
    public Employee(String name, String address, double hourlyRate) {
        super(name, address);
        this.hourlyRate = hourlyRate;
    }

    /**
     * Getter for hourlyRate
     * @return 
     */
    public double getHourlyRate() {
        return hourlyRate;
    }

    /**
     * Setter for hourlyRate
     * @param hourlyRate 
     */
    public void setHourlyRate(double hourlyRate) {
        this.hourlyRate = hourlyRate;
    }

    /**
     * Getter hoursWorked
     * @return 
     */
    public int getHoursWorked() {
        return hoursWorked;
    }

    /**
     * Setter for hoursWorked
     * @param hoursWorked 
     */
    public void setHoursWorked(int hoursWorked) {
        this.hoursWorked = hoursWorked;
    }

    /**
     * Getter for the amount earned
     * @return double
     */
    public double getEarned() {
        return earned;
    }

    /**
     * Setter for earned
     * @param earned 
     */
    public void setEarned(double earned) {
        this.earned = earned;
    }
    
    
    /**
     * Method for calculating the paycheck ever two weeks
     * @param hoursWorkedWeek1
     * @param hoursWorkedWeek2 
     */
    public void payCheckTwoWeeks(int hoursWorkedWeek1, int hoursWorkedWeek2){
        double payCheck = 0;
        if(hoursWorkedWeek1 <= 40){
            payCheck = hoursWorkedWeek1 * hourlyRate;
        }else {
            int tempHours = hoursWorkedWeek1 - 40;
            payCheck = 40 * hourlyRate + (tempHours * (hourlyRate * 1.5));
        }
        
        if(hoursWorkedWeek2 <= 40){
            payCheck += hoursWorkedWeek2 * hourlyRate;
        }else {
            int tempHours = hoursWorkedWeek2 - 40;
            payCheck += 40 * hourlyRate + (tempHours * (hourlyRate * 1.5));
        }
        
        earned += payCheck;
        
        pastHours.add(hoursWorkedWeek1);
        pastHours.add(hoursWorkedWeek2);
        pastPayChecks.add(payCheck);
        
    }
    
    /**
     * Method for printing the past hours worked and the amount in that paycheck
     */
    public void printPastPayChecks(){
        int payCheckNum = 1;
        int pastHoursCounter = 0;
        for(int i = 0; i < pastPayChecks.size(); i++){
            System.out.println("Name: " + this.getName());
            System.out.println("Paycheck " + payCheckNum + ": $" + pastPayChecks.get(i));
            
            System.out.println("Hours for first week: " + pastHours.get(pastHoursCounter) + " Hours for second week: " + pastHours.get(pastHoursCounter+1));
            payCheckNum++;
            pastHoursCounter += 2;
        }
    }
}
