/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package woffortune;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Random;
import java.util.Scanner;

/**
 * WofFortuneGame class
 * Contains all logistics to run the game
 * @author Austin Hill
 */
public class WofFortuneGame {

    private boolean puzzleSolved = false;

    private Wheel wheel;
    private Player player1;
    private String phrase = "Once upon a time";
    //private Letter[] letter_array = new Letter[16];
    private ArrayList<Letter> phrase_holder = new ArrayList<Letter>();
    private ArrayList<String> phrases = new ArrayList<String>();
    private ArrayList<Player> players = new ArrayList<Player>();
    /**
     * Constructor
     * @param wheel Wheel 
     * @throws InterruptedException 
     */
    public WofFortuneGame(Wheel wheel) throws InterruptedException {
        // get the wheel
        this.wheel = wheel;
        
        // do all the initialization for the game
        setUpGame();
        
        

    }
    
    /**
     * Plays the game
     * @throws InterruptedException 
     */
    public void playGame() throws InterruptedException {
        // while the puzzle isn't solved, keep going
        while (!puzzleSolved){
            // let the current player play
            for (int i = 0; i < players.size(); i++){
            playTurn(players.get(i));
            if (puzzleSolved){ //stop the game after one player solves the phrase
                break;
            }
            }
        }
    }
    
    /**
     * add phrases to a list
     */
    public void addPhrases(){
        phrases.add("A bunch of fives");
        phrases.add("A change is as good as a rest");
        phrases.add("A diamond in the rough");
        phrases.add("A diamond is forever");
        phrases.add("A dog is a man's best friend");
        phrases.add("A fate worse than death");
        phrases.add("A fool and his money are soon parted");
        phrases.add("A friend in need is a friend indeed");
        phrases.add("A knight in shining armour");
        phrases.add("A legend in one's own lifetime");
        phrases.add("A little bird told me");
        phrases.add("A nod is as good as a wink");
        phrases.add("A penny for your thoughts");
        phrases.add("Beauty is in the eye of the beholder");
        phrases.add("Better to have loved and lost than never to have loved at all");
        phrases.add("Once upon a time");
    }
    
    /**
     * Sets up all necessary information to run the game
     */
    private void setUpGame() {
        // create a single player 
        player1 = new Player("Player1");
        Scanner sc = new Scanner(System.in);
        int numPlayers = 0;
        String name;
        int playerNum = 1;
        addPhrases();
        
        while(numPlayers < 1){ // finds the number of player can't be -num, 0, or letter
        try{
        System.out.println("Enter the number of players: ");
        numPlayers = sc.nextInt();
        }catch(InputMismatchException ime){
            System.out.println("Exception caught in setUpGame method: " + ime);
            System.out.println("You entered something which is not integer!");
            sc.nextLine();
        } catch(Exception e){
            System.out.println("Exception caught in setUpGame method: " + e);
        }
        }
        
        try {
        for (int i = 0; i < numPlayers; i++){ //get the name of the players
            System.out.println("Enter player " + playerNum + " name: ");
            sc.useDelimiter("\n");
            name = sc.next();
            playerNum++;
            players.add(new Player(name));
        }
        } catch(Exception e){
            System.out.println("Exception caught in setUpGame method: " + e);
        }
        
        
        
        
        
        // print out the rules
        System.out.println("RULES!");
        System.out.println("Each player gets to spin the wheel, to get a number value");
        System.out.println("Each player then gets to guess a letter. If that letter is in the phrase, ");
        System.out.println(" the player will get the amount from the wheel for each occurence of the letter");
        System.out.println("If you have found a letter, you will also get a chance to guess at the phrase");
        System.out.println("Each player only has three guesses, once you have used up your three guesses, ");
        System.out.println("you can still guess letters, but no longer solve the puzzle.");
        System.out.println();
        
        while(true){ // finds out if the player wants to enter a phrase or not and only allows y or no in both lower case and upper
        try{
        // asks for user entered phrase
        System.out.println("Would you like to enter a phrase? Y/N");
        char answer = sc.next().charAt(0);
        if (answer == 'Y' || answer == 'y'){
            System.out.println("Enter phrase: ");
            sc.useDelimiter("\n");
            phrase = sc.next();
            break;
        } else if(answer == 'N' || answer == 'n'){
            Random r = new Random();
            addPhrases();
            int temp = r.nextInt(phrases.size());
            phrase = phrases.get(temp);
            break;
        } else {
            System.out.println("You did not enter Y/y or N/n!");
        }
        }catch(Exception e){
            System.out.println("Exception caught in setUpGame method: " + e);
        }
        }
        
        
        
        
        // for each character in the phrase, create a letter and add to letters array
        for (int i = 0; i < phrase.length(); i++) {
            phrase_holder.add(new Letter(phrase.charAt(i)));
        }
        // setup done
    }
    
    /**
     * One player's turn in the game
     * Spin wheel, pick a letter, choose to solve puzzle if letter found
     * @param player
     * @throws InterruptedException 
     */
    private void playTurn(Player player) throws InterruptedException {
        int money = 0;
        Scanner sc = new Scanner(System.in);
        boolean MOP = false; // Money or Prize used to find out which one to do
        
        try{
        System.out.println(player.getName() + ", you have $" + player.getWinnings());
        System.out.println("Spin the wheel! <press enter>");
        sc.nextLine();
        System.out.println("<SPINNING>");
        } catch(Exception e){ // use to catch a exception
            System.out.println("Exception caught in palyTurn method: " + e);
        }
        
        try{
        Thread.sleep(200);
        } catch(InterruptedException ie){
            System.out.println("Exception caught in palyTurn method: " + ie);
        } catch(Exception e){ 
            System.out.println("Exception caught in palyTurn method: " + e);
        }
        
        Wheel.WedgeType type = wheel.spin();
        System.out.print("The wheel landed on: ");
        switch (type) {
            case MONEY:
                money = wheel.getAmount();
                System.out.println("$" + money);
                MOP = false;
                break;
                
            case LOSE_TURN:
                System.out.println("LOSE A TURN");
                System.out.println("So sorry, you lose a turn.");
                return; // doesn't get to guess letter
                
                
            case BANKRUPT:
                System.out.println("BANKRUPT");
                player.bankrupt();
                return; // doesn't get to guess letter
                
                
            case PRIZE:
                player.potentialPrize();
                MOP = true; // use to print out the right test for prize or money
                break;
                
            default:
                
        }
        System.out.println("");
        System.out.println("Here is the puzzle:");
        showPuzzle();
        System.out.println();
        System.out.println(player.getName() + ", please guess a letter.");
        //String guess = sc.next();
        
        try{
        char letter = sc.next().charAt(0);
        if (!Character.isAlphabetic(letter)) {
            System.out.println("Sorry, but only alphabetic characters are allowed. You lose your turn.");
        } else {
            // search for letter to see if it is in
            int numFound = 0;
            for (Letter l : phrase_holder) {
                if ((l.getLetter() == letter) || (l.getLetter() == Character.toUpperCase(letter))) {
                    l.setFound();
                    numFound += 1;
                }
            }
            if (numFound == 0) {
                System.out.println("Sorry, but there are no " + letter + "'s.");
            } else {
                if (numFound == 1) {
                    System.out.println("Congrats! There is 1 letter " + letter + ":");
                } else {
                    System.out.println("Congrats! There are " + numFound + " letter " + letter + "'s:");
                }
                System.out.println();
                showPuzzle();
                System.out.println();
                if (!MOP){ //see if money or prize
                player.incrementScore(numFound*money);
                System.out.println("You earned $" + (numFound*money) + ", and you now have: $" + player.getWinnings());
                } else{
                    player.wonAPrize();
                }


                System.out.println("Would you like to try to solve the puzzle? (Y/N)");
                letter = sc.next().charAt(0);
                System.out.println();
                if ((letter == 'Y') || (letter == 'y')) {
                    solvePuzzleAttempt(player);
                }
            }
            
            
        }
        } catch(Exception e){
            System.out.println("Exception caught in palyTurn method: " + e);
        }
        
        
    }
    
    /**
     * Logic for when user tries to solve the puzzle
     * @param player 
     */
    private void solvePuzzleAttempt(Player player) {
        
        if (player.getNumGuesses() >= 3) {
            System.out.println("Sorry, but you have used up all your guesses.");
            return;
        }
        
        try {
        player.incrementNumGuesses();
        System.out.println("What is your solution?");
        Scanner sc = new Scanner(System.in);
        sc.useDelimiter("\n");
        String guess = sc.next();
        if (guess.compareToIgnoreCase(phrase) == 0) {
            System.out.println("Congratulations! You guessed it!");
            puzzleSolved = true;
            // Round is over. Write message with final stats
            // TODO
            int winnings = 0;
            String winner = null;
            for (int i = 0; i < players.size(); i++){ // finds the person with the most money and set them as the winner
                if (winnings < players.get(i).getWinnings()){
                    winner = players.get(i).getName();
                    winnings = players.get(i).getWinnings();
                }
            }
            if (winner == null){ // if no one won any money but won a prize this person is the winner
                int prize = 0;
                for (int i = 0; i < players.get(i).prizesSize(); i++){
                    if (prize < players.get(i).prizesSize()){
                    winner = players.get(i).getName();
                    prize = players.get(i).prizesSize();
                    }
                }
            }
            System.out.println("The winner is " + winner); // prints winner
            for (int i = 0; i < players.size(); i++){ //prints stats
                System.out.println(players.get(i).getName() + " winnings was " + players.get(i).getWinnings());
                if (players.get(i).prizesSize() != 0){ // prints prizes if any if non the prints no prizes
                System.out.print("Prizes won: ");
                players.get(i).getPrizes();
                System.out.println();
                } else {
                    System.out.println("Prizes won: No prizes");
                }
            }
            
        } else {
            System.out.println("Sorry, but that is not correct.");
        }
        } catch(Exception e){
            System.out.println("Exception caught in solvePuzzleAttempt method: " + e);
        }
    }
    
    /**
     * Display the puzzle on the console
     */
    private void showPuzzle() {
        System.out.print("\t\t");
        for (Letter l : phrase_holder) {
            if (l.isSpace()) {
                System.out.print("   ");
            } else {
                if (l.isFound()) {
                    System.out.print(Character.toUpperCase(l.getLetter()) + " ");
                } else {
                    System.out.print(" _ ");
                }
            }
        }
        System.out.println();
        
    }
    
    /**
     * For a new game reset player's number of guesses to 0
     */
    public void reset() {
        player1.reset();
    }
  
}
